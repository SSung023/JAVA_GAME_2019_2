package message;

import GFX.Assets;
import GFX.Text;
import entity.Entity;
import main.Handler;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

public class MessageManager{

    private Handler handler;
    private Message message[] = new Message[100];

    private static String resultLine;

    //출력 할 좌료 설정


    public MessageManager(Handler handler){
        this.handler = handler;

        resultLine = "";

        initMessage();


    }

    public void initMessage(){

        //3층 사무실
        message[0] = new Message("딱히 특별한 것은 없는 듯 하다.", 0); // 딱히 별 상호작용 없는 Entity들
        message[1] = new Message("이게 뭐야. 웬 드라이버...?", 1);
        message[2] = new Message("[회사 탈출하려고 하는 거야?\n그럼 이걸 챙겨.]",2);
        message[3] = new Message("직원 : ……………\n정신이 가출한 듯 하다..", 3);  // D
        message[4] = new Message("직원 :크어어억 커억 큭 드르렁~\n나 : 수면실가서 주무시지…", 4);    // D
        message[5] = new Message("직원 :흡…끄흑…또…또 고쳐야 해…\n      흑…끄흡….큭….\n나 : 저런...",5);//
        message[6] = new Message(">부장님 책상<\n지 책상만 깨끗한거 봐라 어휴- 볼 것도 없다.",6);
        message[7] = new Message("직원 : “……………@#@#....#@#$%^@>…….&*^!.\n욕 소리가 들린다.",7);
        message[8] = new Message("철컥철컥,\n역시 열리지 않는다.",8);
        message[9] = new Message("드라이버로 열 수 있는 환풍구다.\n드라이버를 찾아보자",8);
        message[10] = new Message("…!!! 이게열려? 여길 들어가보는 것은 미친짓이지만…\n이 회사에 더 있는 게 미친짓이야.",10);

        //환풍구 안
        message[11] = new Message("마취총과 쪽지를 발견했다...\n인벤토리를 열어보자.",11);
        message[12] = new Message("뭐야 이 미친 사람은...\n아니 이딴게 마취총이라고 나한테 준거야?",12);
        message[13] = new Message("",13);
        message[14] = new Message("",14);
        message[15] = new Message("",15);
        message[16] = new Message("",16);
        message[17] = new Message("",17);
    }

    // Player Class의 checkInteract 메소드에서 id를 받으면
    public void setResultLine(int id){
        resultLine = message[id].getLine();
    }

    public static String getResultLine(){
        return resultLine;
    }


}
